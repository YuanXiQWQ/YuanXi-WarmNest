function total(value1, value2) {
  if (
    value1 !== null &&
    value2 !== null &&
    typeof value1 === "number" &&
    typeof value2 === "number"
  ) {
    return value1 + value2;
  }
  return null;
}
