-- CREATE TABLE Artist (
--   ID int NOT NULL AUTO_INCREMENT,
--   art_ArtistLName VARCHAR(20),
--   art_ArtistFName VARCHAR(20),
--   art_ArtistAddress TEXT,
--   art_ArtistPhone VARCHAR(12),
--   art_ArtistEmail VARCHAR(80),
--   PRIMARY KEY (ID)
-- );

-- CREATE TABLE Painting (
--   ID int NOT NULL AUTO_INCREMENT,
--   art_ID int NOT NULL,
--   ptg_PaintingTitle TEXT,
--   ptg_PaintingDate DATE,
--   ptg_PaintingDesc FLOAT,
--   PRIMARY KEY (ID),
--   FOREIGN KEY (art_id) REFERENCES Artist(ID) ON UPDATE CASCADE ON DELETE CASCADE
-- );  

CREATE TABLE Artist (
  ID int NOT NULL AUTO_INCREMENT,
  lastname VARCHAR(20),
  firstname VARCHAR(20),
  address TEXT,
  phone VARCHAR(12),
  email VARCHAR(80),
  PRIMARY KEY (ID)
);

CREATE TABLE Painting (
  ID int NOT NULL AUTO_INCREMENT,
  artistID int NOT NULL,
  title TEXT,
  paint_date DATE,
  description FLOAT,
  PRIMARY KEY (ID),
  FOREIGN KEY (artistID) REFERENCES Artist(ID) ON UPDATE CASCADE ON DELETE CASCADE
);