[Jiarui Xing], [A01354731], [D], [5thFebruary,2024]

This assignment is [100]% complete.


------------------------
Question one (Change) status:

[complete]

------------------------
Question two (Sqrt) status:

[complete]

------------------------
Question three (Reverse) status:

[complete]

------------------------
Question four (Pack) status:

[complete]
